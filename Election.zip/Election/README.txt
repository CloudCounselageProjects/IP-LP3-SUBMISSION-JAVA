This program requires following dependencies
1.Node-js
2.Chrome Browser(For metamask integration)
2.Metamask
3.Ganache
4.NPM
5.Truffle

How to run the program;
1. cd Election/
2. npm install
4. Run Ganache in background
5.truffle console
6.truffle test//To compile
7.npm run dev
(Change the solidity version incase of a version mismatch)

References For This Project:
Edureka & DAPP University Videos

